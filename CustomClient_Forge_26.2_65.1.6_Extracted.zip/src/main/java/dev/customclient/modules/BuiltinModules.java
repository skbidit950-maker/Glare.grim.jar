package dev.customclient.modules;

import dev.customclient.api.*;

public final class BuiltinModules {
    private BuiltinModules() {}
    public static ModuleRegistry createRegistry() {
        ModuleRegistry registry = new ModuleRegistry();
        registry.register(new BasicModule("hud", "HUD", Category.HUD));
        registry.register(new BasicModule("coordinates", "Coordinates", Category.VISUALS));
        registry.register(new BasicModule("fps", "FPS", Category.VISUALS));
        registry.register(new BasicModule("toggle_sprint", "Toggle Sprint", Category.MOVEMENT));
        return registry;
    }
    private static final class BasicModule extends Module {
        private final Setting<Boolean> visible = setting("Visible", Boolean.class, true);
        BasicModule(String id, String name, Category category) { super(id, name, category); }
        public boolean isVisible() { return visible.get(); }
    }
}
