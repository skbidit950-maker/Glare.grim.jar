# Custom Client — Forge 26.2 / 65.1.6

This project was created from the Forge MDK ZIP you uploaded:
- Minecraft: 26.2
- Forge: 65.1.6
- Java toolchain: 25
- Gradle wrapper: 9.5.0

## Build on Windows
1. Install a JDK 25 (not just a JRE).
2. Extract this project to a short writable path, e.g. `C:\\MCDev\\CustomClient`.
3. Open PowerShell in this folder.
4. Run `.\gradlew.bat build`.
5. If successful, find the mod JAR in `build\\libs\\`.

To launch the Forge dev client:
    .\\gradlew.bat runClient

The first Gradle run downloads Minecraft/Forge dependencies and can take time. Internet access is required.

## Current implementation status
- Forge mod metadata and entry point: integrated from your MDK.
- Module API: categories, settings, lifecycle, registry and exception isolation.
- Registered starter modules: HUD, Coordinates, FPS, Toggle Sprint.
- Not yet implemented: actual ClickGUI, rendering hooks, keybinds, in-game module behavior, persistence, and the remaining Larp-inspired modules.

This is an initial loadable-mod foundation, not a finished feature-complete client. It has not been compiled in this environment. Please run the build and send the full error output if it fails.

## Security and compatibility
Only source code is included. No third-party Larp JARs were copied or executed.
A module is implemented from scratch only after its behavior and compatibility are established.
