package dev.customclient;

import com.mojang.logging.LogUtils;
import dev.customclient.api.ModuleRegistry;
import dev.customclient.modules.BuiltinModules;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

/**
 * Main Forge entry point. The MDK supplied by the user targets Forge 65.1.6 / MC 26.2.
 * Loader-specific rendering and input hooks will be added after the first clean launch.
 */
@Mod(CustomClient.MOD_ID)
public final class CustomClient {
    public static final String MOD_ID = "customclient";
    public static final Logger LOGGER = LogUtils.getLogger();
    public static final ModuleRegistry MODULES = BuiltinModules.createRegistry();

    public CustomClient() {
        LOGGER.info("Custom Client loaded. Registered {} modules.", MODULES.all().size());
        MODULES.all().forEach(module ->
            LOGGER.info("Registered module: {} [{}]", module.displayName(), module.category()));
    }
}
