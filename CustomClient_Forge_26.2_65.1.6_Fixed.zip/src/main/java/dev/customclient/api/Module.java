package dev.customclient.api;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public abstract class Module {
    private final String id, displayName;
    private final Category category;
    private final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;
    protected Module(String id, String displayName, Category category) {
        this.id = Objects.requireNonNull(id);
        this.displayName = Objects.requireNonNull(displayName);
        this.category = Objects.requireNonNull(category);
    }
    public final String id() { return id; }
    public final String displayName() { return displayName; }
    public final Category category() { return category; }
    public final boolean isEnabled() { return enabled; }
    public final List<Setting<?>> settings() { return Collections.unmodifiableList(settings); }
    protected final <T> Setting<T> setting(String name, Class<T> type, T value) {
        Setting<T> result = new Setting<>(name, type, value);
        settings.add(result);
        return result;
    }
    public final void setEnabled(boolean next) {
        if (enabled == next) return;
        if (next) {
            onEnable();
            enabled = true;
        } else {
            try { onDisable(); } finally { enabled = false; }
        }
    }
    public final void toggle() { setEnabled(!enabled); }
    public void onEnable() {}
    public void onDisable() {}
    public void onClientTick() {}
}
