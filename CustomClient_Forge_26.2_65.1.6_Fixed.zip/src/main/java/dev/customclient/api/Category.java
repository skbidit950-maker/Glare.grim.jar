package dev.customclient.api;
public enum Category {
    COMBAT, MOVEMENT, PLAYER, VISUALS, COSMETICS, BASE_FINDING, MISC, DONUT_SMP, HUD
}
