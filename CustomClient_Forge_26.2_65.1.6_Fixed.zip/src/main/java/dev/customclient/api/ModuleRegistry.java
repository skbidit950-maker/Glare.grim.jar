package dev.customclient.api;

import java.util.*;

public final class ModuleRegistry {
    private final Map<String, Module> modules = new LinkedHashMap<>();
    public void register(Module module) {
        Objects.requireNonNull(module);
        String key = module.id().toLowerCase(Locale.ROOT);
        if (modules.putIfAbsent(key, module) != null)
            throw new IllegalArgumentException("Duplicate module id: " + module.id());
    }
    public Optional<Module> find(String id) {
        return Optional.ofNullable(modules.get(id.toLowerCase(Locale.ROOT)));
    }
    public List<Module> all() { return List.copyOf(modules.values()); }
    public List<Module> byCategory(Category category) {
        return modules.values().stream().filter(m -> m.category() == category).toList();
    }
    /** Called by a future client tick adapter; module exceptions are isolated. */
    public Map<String, Throwable> tickEnabledModules() {
        Map<String, Throwable> errors = new LinkedHashMap<>();
        for (Module module : modules.values()) {
            if (!module.isEnabled()) continue;
            try { module.onClientTick(); }
            catch (Throwable error) {
                errors.put(module.id(), error);
                try { module.setEnabled(false); } catch (Throwable ignored) { /* preserve original */ }
            }
        }
        return errors;
    }
}
