package dev.customclient.api;

import java.util.Objects;

public final class Setting<T> {
    private final String name;
    private final Class<T> type;
    private T value;
    public Setting(String name, Class<T> type, T initialValue) {
        this.name = Objects.requireNonNull(name);
        this.type = Objects.requireNonNull(type);
        set(initialValue);
    }
    public String name() { return name; }
    public T get() { return value; }
    public void set(Object next) {
        if (!type.isInstance(next))
            throw new IllegalArgumentException("Setting '" + name + "' expects " + type.getSimpleName());
        value = type.cast(next);
    }
}
